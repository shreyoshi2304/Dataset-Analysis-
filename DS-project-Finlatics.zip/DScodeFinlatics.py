# Importing necessary libraries
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Loading the dataset
df = pd.read_csv(
    r"C:\Users\Shreyoshi\OneDrive\Desktop\DsResearch\Media and Technology\Media and Technology\Global YouTube Statistics.csv",
    encoding='ISO-8859-1'  # Handling special characters in the dataset
)

# Display basic info about the dataset
print(df.info())          # Overview of columns, non-null values, and data types
print(df.describe())      # Statistical summary for numerical columns

# Remove duplicate rows if any
df = df.drop_duplicates()

# Print the shape of the cleaned dataset
print(df.shape)           # Output: (995, X) — Total rows after removing duplicates

# Print all column names
print(df.columns)

# ---------------------------------------------------------
# Removing redundant or unnecessary columns
# ---------------------------------------------------------

df.drop(columns=["Title"], inplace=True)  # 'Title' is not needed for this analysis
df.drop(columns=["Country of origin", "Abbreviation"], inplace=True)  # Already covered by 'Country'

# Confirm remaining columns
print(df.columns)

# ---------------------------------------------------------
# Checking for missing values
# ---------------------------------------------------------

print(df.isnull().sum())  # Count of missing values per column

# Examine rows where 'Population' is missing
missing_population = df[df['Population'].isnull()]
print(missing_population['Country'].value_counts())

# Examine rows where 'Gross tertiary education enrollment (%)' is missing
missing_edu = df[df['Gross tertiary education enrollment (%)'].isnull()]
print(missing_edu['Country'].value_counts(dropna=False))

# Examine rows where 'Unemployment rate' is missing
missing_unemp = df[df['Unemployment rate'].isnull()]
print(missing_unemp['Country'].value_counts(dropna=False))

# ---------------------------------------------------------
# Filling missing data for Andorra (based on external knowledge)
# ---------------------------------------------------------

df.loc[(df['Country'] == 'Andorra') & (df['Population'].isnull()), 'Population'] = 82904
df.loc[(df['Country'] == 'Andorra') & 
       (df['Gross tertiary education enrollment (%)'].isnull()), 
       'Gross tertiary education enrollment (%)'] = 64.28
df.loc[(df['Country'] == 'Andorra') & 
       (df['Unemployment rate'].isnull()), 
       'Unemployment rate'] = 1.6

# ---------------------------------------------------------
# Analysis: Top 10 YouTube Channels by Subscribers
# ---------------------------------------------------------

# Drop rows where 'subscribers' value is missing
df.dropna(subset=['subscribers'], inplace=True)

# Sort the dataframe to get top 10 channels by subscribers
top_10_channels = df.sort_values(by='subscribers', ascending=False).head(10)

# Displaying relevant columns for the top 10 channels
print(top_10_channels[['Youtuber', 'subscribers', 'Country']])

# ---------------------------------------------------------
# Visualizing the top 10 YouTube channels
# ---------------------------------------------------------

plt.figure(figsize=(14, 8))
sns.barplot(data=top_10_channels, x='Youtuber', y='subscribers', palette='viridis')

plt.title('Top 10 YouTube Channels by Subscribers', fontsize=16, weight='bold')
plt.xlabel('YouTube Channel', fontsize=14)
plt.ylabel('Number of Subscribers', fontsize=14)
plt.xticks(rotation=45, ha='right')  # Rotate channel names for better readability
plt.tight_layout()
plt.show()
# ---------------------------------------------------------
# Filling missing values in 'category' with the most frequent category (mode)
# ---------------------------------------------------------
df['category'] = df['category'].fillna(df['category'].mode()[0])

# Grouping by category to compute average subscribers
avg_subs_by_category = df.groupby('category')['subscribers'].mean().sort_values(ascending=False)

# Identifying the category with the highest average subscribers
top_category = avg_subs_by_category.idxmax()
top_avg_subs = avg_subs_by_category.max()

print(f"The category with the highest average subscribers is: {top_category} with an average of {top_avg_subs:.2f} subscribers.")

# Bar plot of average subscribers by category
plt.figure(figsize=(12, 6))
sns.barplot(x=avg_subs_by_category.values, y=avg_subs_by_category.index, palette='coolwarm')
plt.xlabel('Average Subscribers')
plt.ylabel('Category')
plt.title('Average Subscribers by YouTube Category')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Average uploads by category
# ---------------------------------------------------------
avg_uploads_by_category = df.groupby('category')['uploads'].mean().sort_values(ascending=False)

print("Average number of uploads per category:\n", avg_uploads_by_category)

# Bar plot of average uploads
plt.figure(figsize=(12, 6))
sns.barplot(x=avg_uploads_by_category.values, y=avg_uploads_by_category.index, palette='mako')
plt.xlabel('Average Number of Uploads')
plt.ylabel('YouTube Category')
plt.title('Average Uploads per Channel by Category')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Top countries by number of YouTube channels
# ---------------------------------------------------------
# Fill missing country values with mode
df['Country'] = df['Country'].fillna(df['Country'].mode()[0])

# Get top 5 countries by number of channels
top_countries = df['Country'].value_counts().sort_values(ascending=False).head(5)
print("Top 5 countries by number of YouTube channels:\n", top_countries)

# Bar plot for top countries
plt.figure(figsize=(12, 6))
sns.barplot(x=top_countries.values, y=top_countries.index, palette='Set2')
plt.xlabel('Number of YouTube Channels')
plt.ylabel('Country')
plt.title('Top 5 Countries by Number of YouTube Channels')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Distribution of channel types across categories
# ---------------------------------------------------------
# Fill missing values in 'channel_type'
df['channel_type'] = df['channel_type'].fillna(df['channel_type'].mode()[0])

# Create pivot table: count of each channel type per category
channel_type_distribution = pd.pivot_table(df, 
                                           index='category', 
                                           columns='channel_type', 
                                           values='Youtuber', 
                                           aggfunc='count', 
                                           fill_value=0)

print("Channel type distribution across categories:\n", channel_type_distribution)

# Stacked bar chart of channel types by category
channel_type_distribution.plot(kind='bar', stacked=True, figsize=(14, 8), colormap='tab20c')
plt.title('Distribution of Channel Types Across Categories', fontsize=16)
plt.xlabel('YouTube Category', fontsize=12)
plt.ylabel('Number of Channels', fontsize=12)
plt.legend(title='Channel Type', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Correlation between Subscribers and Video Views
# ---------------------------------------------------------
# Selecting numeric columns for correlation
numeric_df = df[['subscribers', 'video views']].copy()

# Compute and visualize correlation matrix
corr_matrix = numeric_df.corr()

plt.figure(figsize=(12, 6))
sns.heatmap(corr_matrix, annot=True, cmap='PuBuGn', fmt='.2f')
plt.title('Correlation between Subscribers and Video Views', fontsize=14)
plt.tight_layout()
plt.show()

# Pair plot to visualize distribution and relationships
sns.pairplot(numeric_df)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Average monthly earnings by category
# ---------------------------------------------------------
# Calculate average of lowest and highest monthly earnings
df['average_monthly_earnings'] = (df['lowest_monthly_earnings'] + df['highest_monthly_earnings']) / 2

# Compute average earnings by category
category_earnings = df.groupby('category')['average_monthly_earnings'].mean().sort_values(ascending=False)

# Bar plot of average monthly earnings
plt.figure(figsize=(12, 6))
sns.barplot(x=category_earnings.values, y=category_earnings.index, palette='crest')
plt.xlabel('Average Monthly Earnings')
plt.ylabel('YouTube Category')
plt.title('Average Monthly Earnings by YouTube Category', fontsize=16)
plt.tight_layout()
plt.show()
# ---------------------------------------------------------
# Handling Missing Values: Subscribers Gained/Lost in Last 30 Days
# ---------------------------------------------------------
df['subscribers_for_last_30_days'] = df['subscribers_for_last_30_days'].fillna(
    df['subscribers_for_last_30_days'].median()
)

# Summary statistics for subscriber changes
print("\n Summary Statistics for Subscribers Gained/Lost (Last 30 Days):\n")
print(df['subscribers_for_last_30_days'].describe())

# Histogram showing distribution of subscriber changes
plt.figure(figsize=(10, 6))
sns.histplot(df['subscribers_for_last_30_days'], bins=20, kde=True, color='skyblue')
plt.xlabel('Subscribers Gained/Lost in Last 30 Days')
plt.title('Distribution of Subscriber Changes (Last 30 Days)')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Top 10 Channels by Subscriber Gain
# ---------------------------------------------------------
top_gainers = df.sort_values(by='subscribers_for_last_30_days', ascending=False).head(10)

print("\n Top 10 Channels by Subscriber Gain (Last 30 Days):\n")
print(top_gainers[['Youtuber', 'subscribers_for_last_30_days', 'Country']])

# Bar plot for top 10 gainers
plt.figure(figsize=(12, 6))
sns.barplot(x=top_gainers['Youtuber'], y=top_gainers['subscribers_for_last_30_days'], palette='Greens_r')
plt.title('Top 10 Channels by Subscriber Gain (Last 30 Days)', fontsize=16)
plt.xlabel('Channel Name')
plt.ylabel('Subscribers Gained')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Top 10 Channels by Subscriber Loss
# ---------------------------------------------------------
top_losers = df.sort_values(by='subscribers_for_last_30_days').head(10)

print("\n Top 10 Channels by Subscriber Loss (Last 30 Days):\n")
print(top_losers[['Youtuber', 'subscribers_for_last_30_days', 'Country']])

# Bar plot for top 10 losers
plt.figure(figsize=(12, 6))
sns.barplot(x=top_losers['Youtuber'], y=top_losers['subscribers_for_last_30_days'], palette='Reds')
plt.title('Top 10 Channels by Subscriber Loss (Last 30 Days)', fontsize=16)
plt.xlabel('Channel Name')
plt.ylabel('Subscribers Lost')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Category-wise Average Subscriber Change (Last 30 Days)
# ---------------------------------------------------------
category_trend = df.groupby('category')['subscribers_for_last_30_days'].mean().sort_values(ascending=False)

plt.figure(figsize=(12, 6))
sns.barplot(x=category_trend.values, y=category_trend.index, palette='crest')
plt.xlabel('Average Subscribers Gained/Lost (Last 30 Days)')
plt.ylabel('Category')
plt.title('Average Subscriber Change by Category')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Country-wise Average Subscriber Gain (Top 10 Countries)
# ---------------------------------------------------------
country_trend = df.groupby('Country')['subscribers_for_last_30_days'].mean().sort_values(ascending=False).head(10)

plt.figure(figsize=(10, 6))
sns.barplot(x=country_trend.values, y=country_trend.index, palette='rocket')
plt.xlabel('Average Subscribers Gained (Last 30 Days)')
plt.ylabel('Country')
plt.title('Top Countries by Average Subscriber Gain (Last 30 Days)')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Outlier Detection in Average Yearly Earnings
# ---------------------------------------------------------
# Calculating average yearly earnings
df['average_yearly_earnings'] = (df['lowest_yearly_earnings'] + df['highest_yearly_earnings']) / 2

# Calculate IQR
Q1 = df['average_yearly_earnings'].quantile(0.25)
Q3 = df['average_yearly_earnings'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

# Find outliers
outliers_income = df[(df['average_yearly_earnings'] < lower_bound) | (df['average_yearly_earnings'] > upper_bound)]

print("Number of Outliers in Average Yearly Earnings:", outliers_income.shape[0])
print(outliers_income[['Youtuber', 'average_yearly_earnings']].sort_values(by='average_yearly_earnings', ascending=False))

# Boxplot for average yearly earnings
plt.figure(figsize=(12, 6))
sns.boxplot(y=df['average_yearly_earnings'], color='skyblue')
plt.title('Boxplot of Average Yearly Earnings (Outlier Detection)')
plt.xlabel('Average Yearly Earnings')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Outlier Detection in Lowest Yearly Earnings
# ---------------------------------------------------------
Q1_low = df['lowest_yearly_earnings'].quantile(0.25)
Q3_low = df['lowest_yearly_earnings'].quantile(0.75)
IQR_low = Q3_low - Q1_low
lower_bound_low = Q1_low - 1.5 * IQR_low
upper_bound_low = Q3_low + 1.5 * IQR_low

outliers_low = df[(df['lowest_yearly_earnings'] < lower_bound_low) | (df['lowest_yearly_earnings'] > upper_bound_low)]

print("\n Outliers in LOWEST Yearly Earnings:", outliers_low.shape[0])
print(outliers_low[['Youtuber', 'lowest_yearly_earnings']].sort_values(by='lowest_yearly_earnings', ascending=False))

plt.figure(figsize=(12, 6))
sns.boxplot(y=df['lowest_yearly_earnings'], color='lightcoral')
plt.title('Boxplot of LOWEST Yearly Earnings (Outlier Detection)', fontsize=14)
plt.ylabel('Lowest Yearly Earnings')
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Outlier Detection in Highest Yearly Earnings
# ---------------------------------------------------------
Q1_high = df['highest_yearly_earnings'].quantile(0.25)
Q3_high = df['highest_yearly_earnings'].quantile(0.75)
IQR_high = Q3_high - Q1_high
lower_bound_high = Q1_high - 1.5 * IQR_high
upper_bound_high = Q3_high + 1.5 * IQR_high

outliers_high = df[(df['highest_yearly_earnings'] < lower_bound_high) | (df['highest_yearly_earnings'] > upper_bound_high)]

print("\n Outliers in HIGHEST Yearly Earnings:", outliers_high.shape[0])
print(outliers_high[['Youtuber', 'highest_yearly_earnings']].sort_values(by='highest_yearly_earnings', ascending=False))

plt.figure(figsize=(12, 6))
sns.boxplot(y=df['highest_yearly_earnings'], color='mediumseagreen')
plt.title('Boxplot of HIGHEST Yearly Earnings (Outlier Detection)', fontsize=14)
plt.ylabel('Highest Yearly Earnings')
plt.tight_layout()
plt.show()
# ---------------------------------------------------------
# Month Mapping for Cleanup and Standardization
# ---------------------------------------------------------
month_mapping = {
    'Jan': 1, 'January': 1, 'Feb': 2, 'February': 2,
    'Mar': 3, 'March': 3, 'Apr': 4, 'April': 4,
    'May': 5, 'Jun': 6, 'June': 6, 'Jul': 7, 'July': 7,
    'Aug': 8, 'August': 8, 'Sep': 9, 'Sept': 9, 'September': 9,
    'Oct': 10, 'October': 10, 'Nov': 11, 'November': 11,
    'Dec': 12, 'December': 12
}

# Replace month names with numeric values
df['created_month'] = df['created_month'].replace(month_mapping)

# Fill missing values in date components
df['created_date'] = df['created_date'].fillna(df['created_date'].median())
df['created_month'] = df['created_month'].fillna(df['created_month'].mode()[0])
df['created_year'] = df['created_year'].fillna(df['created_year'].mode()[0])

# Convert to integers
df['created_year'] = df['created_year'].astype(int)
df['created_month'] = df['created_month'].astype(int)
df['created_date'] = df['created_date'].astype(int)

# Combine into a single datetime column
df['created_full_date'] = pd.to_datetime(dict(
    year=df['created_year'],
    month=df['created_month'],
    day=df['created_date']
), errors='coerce')

# Remove invalid dates
df = df[df['created_full_date'].notnull()]

# Create a 'YearMonth' period for trend analysis
df['YearMonth'] = df['created_full_date'].dt.to_period('M')

# Display sample channel creation periods
print(df['YearMonth'].value_counts().head())

# ---------------------------------------------------------
# Plot: Monthly Channel Creation Trend
# ---------------------------------------------------------
channels_per_month = df['YearMonth'].value_counts().sort_index()

plt.figure(figsize=(16, 8))
channels_per_month.plot(kind='line', marker='o', color='teal')
plt.title('YouTube Channel Creation Trend Over Time (Monthly)', fontsize=16)
plt.xlabel('Year-Month')
plt.ylabel('Number of Channels Created')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Top 10 Most Active Periods for Channel Creation
# ---------------------------------------------------------
creation_counts = df['YearMonth'].value_counts().sort_values(ascending=False)
top10_creation_times = creation_counts.head(10)

plt.figure(figsize=(12, 6))
sns.barplot(x=top10_creation_times.index.astype(str), y=top10_creation_times.values, palette='viridis')
plt.title('Top 10 Most Frequent Times of YouTube Channel Creation', fontsize=16)
plt.xlabel('Year-Month', fontsize=12)
plt.ylabel('Number of Channels Created', fontsize=12)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Relationship Between Education and Number of Channels
# ---------------------------------------------------------
# Count YouTube channels by country
channel_counts = df.groupby('Country')['Youtuber'].count().reset_index()
channel_counts.rename(columns={'Youtuber': 'Number_of_Channels'}, inplace=True)

# Get education data and merge
edu_data = df[['Country', 'Gross tertiary education enrollment (%)']].drop_duplicates()
channel_edu_df = pd.merge(channel_counts, edu_data, on='Country', how='left')
channel_edu_df = channel_edu_df.dropna(subset=['Gross tertiary education enrollment (%)'])

# Scatter plot
plt.figure(figsize=(12, 7))
sns.scatterplot(data=channel_edu_df,
                x='Gross tertiary education enrollment (%)',
                y='Number_of_Channels',
                hue='Country',
                s=100, palette='tab10', legend=False)
plt.title('Tertiary Education vs. YouTube Channel Count', fontsize=16)
plt.xlabel('Gross Tertiary Education Enrollment (%)', fontsize=12)
plt.ylabel('Number of YouTube Channels', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# Correlation
correlation = channel_edu_df['Gross tertiary education enrollment (%)'].corr(channel_edu_df['Number_of_Channels'])
print(f"Correlation between Education Enrollment and Channel Count: {correlation:.2f}")

# Heatmap of correlation
corr_edu = channel_edu_df[['Number_of_Channels', 'Gross tertiary education enrollment (%)']].corr()

plt.figure(figsize=(10, 6))
sns.heatmap(corr_edu, annot=True, cmap='YlGnBu', fmt='.2f', linewidths=0.5, square=True)
plt.title('Correlation Heatmap: Education vs YouTube Channels', fontsize=14)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Unemployment Rate in Top 10 YouTube-Producing Countries
# ---------------------------------------------------------
unempdf = df.dropna(subset=['Unemployment rate'])
unemp_data = unempdf[['Country', 'Unemployment rate']].drop_duplicates()

# Merge and get top 10
channel_unemp_df = pd.merge(channel_counts, unemp_data, on='Country', how='left')
top10_countries = channel_unemp_df.sort_values(by='Number_of_Channels', ascending=False).head(10)

plt.figure(figsize=(12, 7))
sns.barplot(data=top10_countries, x='Country', y='Unemployment rate', palette='mako')
plt.title('Unemployment Rate in Top 10 Countries by Channel Count', fontsize=16)
plt.xlabel('Country', fontsize=12)
plt.ylabel('Unemployment Rate (%)', fontsize=12)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Urban Population in Countries by Channel Count
# ---------------------------------------------------------
urbandf = df.dropna(subset=['Urban_population'])
urbangroupdf = urbandf.groupby('Country')['Urban_population'].mean().reset_index()
urban_count = pd.merge(urbangroupdf, channel_counts, on="Country", how="left")

# Top 15
top15_countries = urban_count.sort_values(by='Number_of_Channels', ascending=False).head(15)

plt.figure(figsize=(12, 8))
sns.barplot(data=top15_countries, x="Country", y="Urban_population", palette='mako')
plt.title('Urban Population in Top 15 Countries by Channel Count', fontsize=16)
plt.xlabel('Country', fontsize=12)
plt.ylabel('Urban Population (%)', fontsize=12)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# Bottom 15
bottom15_countries = urban_count.sort_values(by='Number_of_Channels', ascending=False).tail(15)

plt.figure(figsize=(12, 8))
sns.barplot(data=bottom15_countries, x="Country", y="Urban_population", palette='mako')
plt.title('Urban Population in Bottom 15 Countries by Channel Count', fontsize=16)
plt.xlabel('Country', fontsize=12)
plt.ylabel('Urban Population (%)', fontsize=12)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# ---------------------------------------------------------
# Geographic Distribution of YouTube Channels (Plotly Map)
# ---------------------------------------------------------
import plotly.express as px
import plotly.io as pio

# Set default renderer (important for Spyder)
pio.renderers.default = 'browser'

# Remove rows with missing coordinates
geo_df = df.dropna(subset=['Latitude', 'Longitude'])
print("Channels with valid coordinates:", geo_df.shape)

# Scatter geo plot
fig = px.scatter_geo(
    geo_df,
    lat='Latitude',
    lon='Longitude',
    hover_name='Youtuber',
    color='Country',
    title='Global Distribution of YouTube Channels',
    projection='natural earth',
    opacity=0.7
)

fig.update_layout(height=600, margin={"r": 0, "t": 40, "l": 0, "b": 0})
fig.show()
# -------------------------------------------
# Correlation Between Subscribers and Population
# -------------------------------------------

# Group by Country: total subscribers and population (assuming population is constant per country)
subs_pop = df.groupby('Country').agg({
    'subscribers': 'sum',
    'Population': 'first'
}).dropna()

# Calculate correlation between population and subscribers
corr = subs_pop['subscribers'].corr(subs_pop['Population'])
print(f"Correlation between total subscribers and population: {corr:.2f}")

# Scatter plot: Population vs Subscribers
plt.figure(figsize=(10,6))
sns.scatterplot(data=subs_pop, x='Population', y='subscribers', s=100, alpha=0.7)
plt.title('Subscribers vs Population by Country')
plt.xlabel('Population')
plt.ylabel('Total Subscribers')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

corr_subs_pop = subs_pop.corr() 
plt.figure(figsize=(8,6))
sns.heatmap(corr_subs_pop , annot=True, cmap='YlGnBu', fmt='.2f')
plt.title('Correlation Heatmap: Subscribers vs Population', fontsize=14)
plt.tight_layout()
plt.show()

# -------------------------------------------
# Population of Top 10 Countries by Channel Count
# -------------------------------------------

top_countries = df['Country'].value_counts().head(10).index
top_countries_df = df[df['Country'].isin(top_countries)].drop_duplicates(subset=['Country'])

plt.figure(figsize=(12,7))
sns.barplot(data=top_countries_df, x='Country', y='Population', palette='rocket')
plt.title('Top 10 Countries by Number of YouTube Channels vs Population')
plt.xlabel('Country')
plt.ylabel('Population')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# -------------------------------------------
# Correlation Between Subscribers Gained and Unemployment Rate
# -------------------------------------------

# Filter data to remove missing values
subs_unemp_df = df[['Country', 'subscribers_for_last_30_days', 'Unemployment rate']].dropna()

# Aggregate by country
subs_unemp_agg = subs_unemp_df.groupby('Country').agg({
    'subscribers_for_last_30_days': 'sum',
    'Unemployment rate': 'first'
}).reset_index()

# Compute correlation
corr = subs_unemp_agg['subscribers_for_last_30_days'].corr(subs_unemp_agg['Unemployment rate'])
print(f"Correlation between subscribers gained and unemployment rate: {corr:.2f}")

# Scatter Plot: Unemployment vs Subscribers Gained
plt.figure(figsize=(10,6))
sns.scatterplot(data=subs_unemp_agg, x='Unemployment rate', y='subscribers_for_last_30_days', s=100, color='purple')
plt.title('Subscribers Gained vs Unemployment Rate')
plt.xlabel('Unemployment Rate (%)')
plt.ylabel('Subscribers Gained (Last 30 Days)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# Heatmap of correlation (selecting only numeric columns)
corr_subs_unemp = subs_unemp_agg[['subscribers_for_last_30_days', 'Unemployment rate']].corr() 
plt.figure(figsize=(6,5))
sns.heatmap(corr_subs_unemp, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5, square=True)
plt.title('Correlation Heatmap:\nSubscribers Gained vs Unemployment Rate', fontsize=14)
plt.tight_layout()
plt.show()

# -------------------------------------------
# Boxplot of Video Views by Channel Type
# -------------------------------------------

dfvideo_views = df["video_views_for_the_last_30_days"].dropna()

plt.figure(figsize=(14,8))
sns.boxplot(data=df, x='channel_type', y='video_views_for_the_last_30_days', palette='coolwarm')
plt.title('Video Views in Last 30 Days by Channel Type')
plt.xlabel('Channel Type')
plt.ylabel('Video Views (Last 30 Days)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#--------------------------------------------------------------------------
# Grouping the data by channel creation month and calculating average uploads
#--------------------------------------------------------------------------

upload_by_month = df.groupby('created_month')['uploads'].mean()

# Bar plot to visualize average uploads by month of creation
plt.figure(figsize=(10,6))
upload_by_month.plot(kind='bar', color='orange')

plt.title('Average Number of Uploads by Channel Creation Month')
plt.xlabel('Creation Month')
plt.ylabel('Average Number of Uploads')
plt.tight_layout()
plt.show()


#-------------------------------------------------------------------
# Average number of subscribers gained per month
#--------------------------------------------------------------------

# Getting today's date for calculating channel age
today = pd.to_datetime('today')

# Calculating channel age in months from the creation date
df['channel_age_months'] = ((today - df['created_full_date']).dt.days / 30).clip(lower=1)  # Clip to avoid division by zero

# Calculating average subscribers gained per month
df['subs_per_month'] = df['subscribers'] / df['channel_age_months']

# Histogram to show distribution of subscribers gained per month
plt.figure(figsize=(12,6))
sns.histplot(df['subs_per_month'], bins=50, color='teal', kde=True)
plt.title('Distribution of Average Subscribers Gained Per Month')
plt.xlabel('Subscribers Gained Per Month')
plt.ylabel('Number of Channels')
plt.tight_layout()
plt.show()

# Displaying top 10 fastest-growing YouTube channels by subs per month
top_gainers = df[['Youtuber', 'subs_per_month']].sort_values(by='subs_per_month', ascending=False).head(10)
print(top_gainers)

# Bar plot to visualize top 10 fastest-growing YouTube channels
plt.figure(figsize=(12,6))
sns.barplot(data=top_gainers, x='Youtuber', y='subs_per_month', palette='crest')
plt.title('Top 10 Fastest Growing YouTube Channels (Subscribers Gained per Month)')
plt.xlabel('Channel Name')
plt.ylabel('Average Subscribers Gained per Month')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

#------------------end------------------------------------------------------
